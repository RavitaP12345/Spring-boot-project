package com.example.microservice2.resources;

import com.example.microservice2.models.CollegeModel;
import com.example.microservice2.models.StudentMailModel;
import com.example.microservice2.models.StudentModel;
import com.example.microservice2.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("std")
public class StudentResource {
    @Autowired
    private StudentService studentService;

    @PostMapping("/saveStudentDetails")
    public ResponseEntity<?> saveStudentDetails(@RequestBody StudentMailModel studentModel){
        return studentService.saveStudentDetails(studentModel);
    }
    @GetMapping("/getAllStudentDetails")
    public List<StudentMailModel> getAllStudentDetails(){
        return studentService.getAllStudentDetails();
    }
    @GetMapping("/getStudentDetailsByStudentId/{studentId}")
    public StudentMailModel getStudentDetailsByStudentId(@PathVariable String studentId){
        return studentService.getStudentDetailsByStudentId(studentId);
    }
    @DeleteMapping("/deleteStudentDetailsByStudentId/{studentId}")
    public ResponseEntity<?> deleteStudentDetailsByStudentId(@PathVariable String studentId){
        return studentService.deleteStudentDetailsByStudentId(studentId);
    }
    @PutMapping("/updateStudentDetails")
    public ResponseEntity<?> updateStudentDetails(@RequestBody StudentMailModel studentModel){
        return studentService.updateStudentDetails(studentModel);
    }
    @GetMapping("/getCollegeDetailsByStudentId/{studentId}")
    public CollegeModel getCollegeDetailsByStudentId(@PathVariable String studentId){
        return studentService.getCollegeDetailsByStudentId(studentId);
    }
    @GetMapping("/getAllCollegeDetails")
    public List<CollegeModel> getAllCollegeDetails(){
        return studentService.getAllCollegeDetails();
    }


}
