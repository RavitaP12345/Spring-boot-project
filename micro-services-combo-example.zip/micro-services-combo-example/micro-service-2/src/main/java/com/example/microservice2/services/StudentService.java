package com.example.microservice2.services;

import com.example.microservice2.entities.StudentEntity;
import com.example.microservice2.models.CollegeModel;
import com.example.microservice2.models.StudentMailModel;
import com.example.microservice2.models.StudentModel;
import com.example.microservice2.repositories.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private RestTemplate restTemplate;
    public ResponseEntity<?> saveStudentDetails(StudentMailModel studentModel) {
        StudentEntity student = new StudentEntity();
        student.setStudentName(studentModel.getStudentName());
        student.setStudentEmail(studentModel.getStudentEmail());
        student.setStudentMobile(studentModel.getStudentMobile());
        studentRepository.save(student);
        return new ResponseEntity<>("Success", HttpStatus.OK);
    }

    public List<StudentMailModel> getAllStudentDetails() {
        List<StudentEntity> studentEntities = studentRepository.findAll();
        List<StudentMailModel> studentModels = new ArrayList<>();
        studentEntities.forEach(data->{
            StudentMailModel studentModel = new StudentMailModel();
            studentModel.setStudentId(data.getStudentId());
            studentModel.setStudentEmail(data.getStudentEmail());
            studentModel.setStudentMobile(data.getStudentMobile());
            studentModel.setStudentName(data.getStudentName());
            studentModels.add(studentModel);
        });
        return studentModels;
    }

    public StudentMailModel getStudentDetailsByStudentId(String studentId) {
        StudentMailModel studentModel = new StudentMailModel();
        StudentEntity student = studentRepository.findStudentByStudentId(Long.valueOf(studentId));
        studentModel.setStudentId(student.getStudentId());
        studentModel.setStudentName(student.getStudentName());
        studentModel.setStudentMobile(student.getStudentMobile());
        studentModel.setStudentEmail(student.getStudentEmail());
        return studentModel;
    }

    public ResponseEntity<?> deleteStudentDetailsByStudentId(String studentId) {
        StudentEntity student = studentRepository.findStudentByStudentId(Long.valueOf(studentId));
        studentRepository.delete(student);
        return new ResponseEntity<>("Deleted", HttpStatus.OK);
    }

    public ResponseEntity<?> updateStudentDetails(StudentMailModel studentModel) {
        if(studentModel.getStudentId()!=null){
            StudentEntity studentEntity = studentRepository.findStudentByStudentId(studentModel.getStudentId());
            if(studentEntity!=null){
                studentEntity.setStudentName(studentModel.getStudentName());
                studentEntity.setStudentMobile(studentModel.getStudentMobile());
                studentEntity.setStudentEmail(studentModel.getStudentEmail());
                studentRepository.save(studentEntity);
                return new ResponseEntity<>("Success", HttpStatus.OK);
            }else {
                return new ResponseEntity<>("Student is not present with given student id", HttpStatus.FORBIDDEN);
            }

        }else {
            return new ResponseEntity<>("Student is is not comming from the model.", HttpStatus.OK);
        }
    }

    public CollegeModel getCollegeDetailsByStudentId(String studentId) {
        CollegeModel collegeModel = restTemplate.getForObject("http://127.0.0.1:1002/stdd/getCollegeDetailsByStudentId/"+studentId, CollegeModel.class);
        return collegeModel;
    }

    public List<CollegeModel> getAllCollegeDetails() {
        List collegeModelList = restTemplate.getForObject("http://127.0.0.1:1002/stdd/getAllCollegeListOfStudents", List.class);
        return collegeModelList;
    }
}
